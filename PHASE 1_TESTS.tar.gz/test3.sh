#!/bin/sh

echo "===SORTIE DU READELF===
"
readelf -x $1 $2
echo "

===SORTIE DU PROGRAMME PRINTELF===
"
./printelf -x $1 $2
