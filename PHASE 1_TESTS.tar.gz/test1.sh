#!/bin/sh

echo "===SORTIE DU READELF===
"
readelf -h $1
echo "

===SORTIE DU PROGRAMME PRINTELF===
"
./printelf -h $1
