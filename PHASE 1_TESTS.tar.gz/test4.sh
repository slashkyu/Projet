#!/bin/sh

echo "===SORTIE DU READELF===
"
readelf -s $1
echo "

===SORTIE DU PROGRAMME PRINTELF===
"
./printelf -s $1
