#!/bin/sh

echo "===SORTIE DU READELF===
"
readelf -r $1
echo "

===SORTIE DU PROGRAMME PRINTELF===
"
./printelf -r $1
