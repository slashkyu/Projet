====LISTE DES TESTS====

PHASE 1

1. AFFICHAGE DU HEADER
./test1.sh <nom_de_fichier>
affiche le résultat d'un readelf -h sur le fichier en argument, puis le résultat de notre propre programme

2. AFFICHAGE DE LA SECTION TABLE
./test2.sh <nom_de_fichier>
affiche le résultat d'un readelf -S sur le fichier en argument, puis le résultat de notre propre programme

3. AFFICHAGE DU CONTENU D'UNE SECTION
./test3.sh <num|nom_de_section> <nom_de_fichier>
affiche le résultat d'un readelf -x <num|nom_de_section> sur le ficher en argument, puis le résultat de 
notre propre programme

4. AFFICHAGE DE LA TABLE DES SYMBOLES
./test4.sh <nom_de_fichier>
affiche le résultat d'un readelf -s sur le fichier en argument, puis le résultat de notre programme

5. AFFICHAGE DE LA TABLE DES REIMPLANTATION
./test5.sh <nom_de_fichier>
affiche le résultat d'un readelf -r sur le fichier en argument, puis le résultat de notre programme