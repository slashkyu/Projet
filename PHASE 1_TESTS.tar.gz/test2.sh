#!/bin/sh

echo "===SORTIE DU READELF===
"
readelf -S $1
echo "

===SORTIE DU PROGRAMME PRINTELF===
"
./printelf -S $1
