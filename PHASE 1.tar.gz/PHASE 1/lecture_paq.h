#ifndef __LECTURE_PAQ_H__
#define __LECTURE_PAQ_H__

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <elf.h>

void decode_ARM_machine_flags (unsigned e_flags, char buf[]);
char *get_machine_flags (unsigned e_flags, unsigned e_machine);

// Procédure d'affichage des infos du header ELF
void print_header(Elf32_Ehdr * data);	//ETAPE 1
const char *get_section_type_name (unsigned int sh_type);
void print_section_table(Elf32_Ehdr * data);	//ETAPE 2
void print_section(Elf32_Ehdr * data, char* section_string);	//ETAPE 3
Elf32_Shdr *get_section_header(Elf32_Ehdr* data, int indice);
Elf32_Shdr *sectionShstrtab(Elf32_Ehdr* data);
Elf32_Shdr *sectionStrtab(Elf32_Ehdr* data);
int sectionRelE(Elf32_Ehdr* data);
int sectionRelaE(Elf32_Ehdr* data);
void print_sym(Elf32_Ehdr * data);	//ETAPE 4
void afficherReloc(Elf32_Ehdr *data);	//ETAPE 5
int check_format(Elf32_Ehdr * data);

#endif
