v2
1.	Se connecter en ssh sur Mandelbrot (plus sûre pour la validation de la compilation)
2.	Dans un même repertoire vous devez avoir le section_header_table.c et le Makefile
3.	entrez la commande : 
make section_header_table
4.	lancez le programme avec la commande :
./section_header_table <nom_de_fichier>
