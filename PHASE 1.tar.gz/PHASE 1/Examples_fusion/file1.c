void afficher();
int main() {
	afficher();
	return 0;
}
