﻿1.	Se connecter en ssh sur Mandelbrot (plus sûre pour la validation de la compilation)

2.	Dans un même repertoire vous devez avoir le readelf.c, lecture_paq.c, lecture_paq.h et le Makefile

3.	entrez la commande : 
make printelf

4.	lancez le programme avec la commande :
./printelf <commande(s)> <nom_de_fichier> 

Le programme accepte les commandes courtes (-@) et longues (--@@..) suivantes :

-h ou --file-header : affiche l'en-tête
-S ou --section-headers ou --sections : affiche la table des sections
-x <num|nom de section> ou --hexdump <num|nom de section> : affiche le contenu de <num|nom de section>, si elle existe
-s ou --syms ou --symbols : affiche la table des symboles
-r ou --relocs : affiche la tables des réimplantations
-a ou --all : similaire à -h -S -s -r

Exemples d'utilisation :
./readelf -h -S file.o
=>affiche le header et la section table du fichier file.o

./readelf -a -x .text -x 10 file.o
=>affiche le header, la section table, la table des symboles, la table des relocations, et 
le contenu de la section ".text" et de la section numéro 10, si elles existent
