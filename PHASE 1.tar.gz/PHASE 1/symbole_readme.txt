﻿1.	Se connecter en ssh sur Mandelbrot (plus sûre pour la validation de la compilation)

2.	Dans un même repertoire vous devez avoir le symbole.c et le Makefile

3.	entrez la commande : 
make symbole

4.	lancez le programme avec la commande :
./symbole <nom_de_fichier> 
