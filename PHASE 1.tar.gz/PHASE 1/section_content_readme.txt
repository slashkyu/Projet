﻿v2
1.	Se connecter en ssh sur Mandelbrot (plus sûre pour la validation de la compilation)

2.	Dans un même repertoire vous devez avoir le section_content.c et le Makefile

3.	entrez la commande : 
make section_content

4.	lancez le programme avec la commande :
./section_content <nom_de_fichier> <no|nom de la section>

P.S. pour savoir les noms et numéros de section utilisez section header table ou readelf -S <ndfichier>
