#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <elf.h>
#include "lecture_paq.h"

void usage(char *name) {
	fprintf(stderr, "Usage:\n"
		"%s [ -a --all ] [ -h --file-header ] [ -S --section-header --sections ] [ -x --hex-dump <number|name> ] [ -s --syms -symbols ] [ -r --relocs ] ELF_file\n\n"
		"\n" 
		, name);
}

int main(int argc, char *argv[]) {
	int opt, file_descriptor, h=0, sec=0, sym=0, r=0;
	char *hexdump;
	Elf32_Ehdr *data;
	struct stat file_info;

	struct option longopts[] = {
		{ "all", no_argument, NULL, 'a'},
		{ "file-header", no_argument, NULL, 'h' },
		{ "section-headers", no_argument, NULL, 'S' },
		{ "sections", no_argument, NULL, 'S' },
		{ "hexdump", required_argument, NULL, 'x' },
		{ "syms", no_argument, NULL, 's' },
		{ "symbols", no_argument, NULL, 's' },
		{ "relocs", no_argument, NULL, 'r'},
		{ NULL, 0, NULL, 0 }
	};

	if (open(argv[argc-1], O_RDONLY) <= 0){
		printf("%s\n",argv[argc-1]);
		fprintf(stderr,"Ouverture du fichier impossible\n");
	}
	else{
		file_descriptor = open(argv[argc-1], O_RDONLY);
		if (fstat(file_descriptor, &file_info)){
			fprintf(stderr, "Recuperation des informations du fichier impossible\n");
		}
		else if ((data = mmap(0, file_info.st_size, PROT_READ, MAP_PRIVATE, file_descriptor, 0)) == MAP_FAILED){
			fprintf(stderr,"Chargement du fichier en memoire impossible\n");
		}
		else if (check_format(data)){
			while ((opt = getopt_long(argc, argv, "ahSx:sr", longopts, NULL)) != -1) {
				switch(opt) {
				case 'a':
					print_header(data);
					h = 1;
					print_section_table(data);
					sec = 1;
					print_sym(data);
					sym = 1;
					afficherReloc(data);
					r = 1;
					break;
				case 'h':
					if (h == 0){
						print_header(data);
						h = 1;
					}
					break;
				case 'S':
					if (sec == 0){
						print_section_table(data);
						sec = 1;
					}
					break;
				case 'x':
					hexdump = optarg;
					print_section(data, hexdump);
					break;
				case 's':
					if (sym == 0){
						print_sym(data);
						sym = 1;
					}
					break;
				case 'r':
					if (r == 0){
						afficherReloc(data);
						r = 1;
					}
					break;
				default:
					fprintf(stderr, "%c : option non reconnue\n", opt);
					usage(argv[0]);
					exit(1);
				}
			}
		munmap(data, file_info.st_size);
		}
	close(file_descriptor);
	}
	return 0;
}
