1.	Se connecter en ssh sur Mandelbrot (plus sûre pour la validation de la compilation)
2.	Dans un même repertoire vous devez avoir le header.c et le Makefile
3.	entrez la commande : 
make header
4.	lancez le programme avec la commande :
./header <nom_de_fichier>
